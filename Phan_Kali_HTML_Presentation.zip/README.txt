# Bài thuyết trình HTML — PHÂN KALI

## Cách mở
1. Giải nén thư mục.
2. Mở `index.html` bằng Chrome/Edge.
3. Dùng `←` `→` hoặc phím cách để chuyển slide.
4. Nhấn `F` hoặc nút `⛶` để trình chiếu toàn màn hình.

## Cấu trúc
- `index.html`: 16 slide và nội dung.
- `style.css`: giao diện, responsive, animation/effect.
- `app.js`: điều khiển chuyển slide, progress, fullscreen, cảm ứng.
- `assets/`: thư mục dành cho tài nguyên cục bộ.

## Lưu ý ảnh
Một số ảnh minh họa được tải từ các trang nguồn bên ngoài nên cần Internet khi trình chiếu. Nếu muốn bản hoàn toàn offline, hãy tải các ảnh từ nguồn hợp lệ về `assets/` và đổi `src` trong `index.html`.

## Nội dung
Bài chỉ tập trung vào PHÂN KALI: khái niệm, K⁺ trong đất, phương trình hòa tan, vai trò sinh lý, thiếu/thừa kali, KCl, K₂SO₄, KNO₃, so sánh, tình huống lựa chọn và nguyên tắc bón.
