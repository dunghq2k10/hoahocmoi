const slides=[...document.querySelectorAll(".slide")];
let index=0;
const bar=document.getElementById("progressBar"), counter=document.getElementById("counter");
function show(i,dir=1){
  index=(i+slides.length)%slides.length;
  slides.forEach((s,n)=>s.classList.toggle("active",n===index));
  bar.style.width=((index+1)/slides.length*100)+"%";
  counter.textContent=String(index+1).padStart(2,"0")+" / "+String(slides.length).padStart(2,"0");
  document.title=(slides[index].dataset.title||"Phân kali")+" — Hóa học 11";
}
function next(){show(index+1,1)} function prev(){show(index-1,-1)}
document.getElementById("next").onclick=next;
document.getElementById("prev").onclick=prev;
document.getElementById("fs").onclick=()=>document.documentElement.requestFullscreen?.();
document.addEventListener("keydown",e=>{
  if(["ArrowRight","PageDown"," "].includes(e.key)){e.preventDefault();next()}
  if(["ArrowLeft","PageUp"].includes(e.key)){e.preventDefault();prev()}
  if(e.key==="Home"){e.preventDefault();show(0)}
  if(e.key==="End"){e.preventDefault();show(slides.length-1)}
  if(e.key.toLowerCase()==="f"){document.documentElement.requestFullscreen?.()}
});
let sx=null;
document.addEventListener("touchstart",e=>sx=e.changedTouches[0].screenX,{passive:true});
document.addEventListener("touchend",e=>{if(sx===null)return;const dx=e.changedTouches[0].screenX-sx;if(Math.abs(dx)>50)dx<0?next():prev();sx=null},{passive:true});
show(0);
